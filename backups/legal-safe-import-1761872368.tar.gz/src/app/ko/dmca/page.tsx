import LegalLayout from "@/components/legal/LegalLayout";
import Content from "./content";
export default function Page(){ return <LegalLayout title="저작권"><Content/></LegalLayout>; }
