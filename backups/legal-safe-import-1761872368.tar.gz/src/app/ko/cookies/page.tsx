import LegalLayout from "@/components/legal/LegalLayout";
import Content from "./content";
export default function Page(){ return <LegalLayout title="쿠키 정책"><Content/></LegalLayout>; }
