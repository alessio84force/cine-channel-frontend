import LegalLayout from "@/components/legal/LegalLayout";
import Content from "./content";
export default function Page(){ return <LegalLayout title="개인정보 처리방침"><Content/></LegalLayout>; }
