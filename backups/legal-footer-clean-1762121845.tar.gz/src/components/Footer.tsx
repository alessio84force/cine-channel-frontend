"use client";
import Link from "next/link";
import { dict, LOCALES, type Locale } from "@/i18n/dict";

export default function Footer({ locale = "es" as Locale }:{ locale?: Locale }) {
  const lang = (LOCALES.includes(locale) ? locale : "es") as Locale;
  const t = dict[lang] || dict.es;
  const F = (t as any).footer || (dict.es as any).footer;
  const year = new Date().getFullYear();

  // Link legali (solo blocco superiore, 3 colonne). Nomi localizzati già presenti nel dizionario.
  const col1 = [
    { href: `/${lang}/terms`, label: F.terms },
    { href: `/${lang}/privacy`, label: F.privacy },
    { href: `/${lang}/cookies`, label: "Cookies" }, // se hai chiave localizzata, sostituisci qui
    { href: `/${lang}/dmca`, label: "DMCA" },
  ];

  const col2 = [
    { href: `/${lang}/imprint`, label: F.imprint },
    { href: `/${lang}/accessibility`, label: F.accessibility },
    { href: `/${lang}/help`, label: F.help },
  ];

  const col3 = [
    { href: `/${lang}/careers`, label: F.careers },
    { href: `/${lang}/press`, label: F.press },
    { href: `/${lang}/contact`, label: F.contact },
    { href: `/${lang}/about`, label: F.about },
  ];

  const linkCls = "block hover:underline text-white/80 hover:text-white";
  const colCls = "space-y-2";

  return (
    <footer className="mt-16 border-t border-white/10">
      {/* BLOCCO ALTO: solo 3 colonne di link legali (niente colonna brand) */}
      <div className="max-w-6xl mx-auto px-6 py-8 grid grid-cols-1 sm:grid-cols-3 gap-6 text-sm">
        <div className={colCls}>
          {col1.map((l) => <Link key={l.href} href={l.href} className={linkCls}>{l.label}</Link>)}
        </div>
        <div className={colCls}>
          {col2.map((l) => <Link key={l.href} href={l.href} className={linkCls}>{l.label}</Link>)}
        </div>
        <div className={colCls}>
          {col3.map((l) => <Link key={l.href} href={l.href} className={linkCls}>{l.label}</Link>)}
        </div>
      </div>

      {/* BLOCCO BASSO: SOLO testo centrale © 2025 Cine-Channel — diritti (niente link a destra) */}
      <div className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-4 text-xs text-white/70 text-center">
          © {year} Cine-Channel — {F.rights}
        </div>
      </div>
    </footer>
  );
}
