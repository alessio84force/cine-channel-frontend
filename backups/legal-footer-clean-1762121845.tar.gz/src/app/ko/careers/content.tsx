export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>채용</h2>
      <p>Cine-Channel과 함께하세요. EU/라틴아메리카 분산 팀. 기회균등, GDPR 준수.</p>
      <h3>2025 공개 채용</h3>
      <ul>
        <li>프론트엔드 (Next.js/React)</li>
        <li>백엔드 (Node/Prisma/PostgreSQL)</li>
        <li>비디오/스트리밍 엔지니어</li>
        <li>커뮤니티 &amp; 파트너십</li>
      </ul>
      <p>이력서와 포트폴리오를 <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> 로 보내주세요. 가능 시점과 연봉 범위를 포함해 주세요.</p>
    </div>
  );
}
