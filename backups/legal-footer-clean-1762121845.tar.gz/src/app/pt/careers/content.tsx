export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Carreiras</h2>
      <p>Junte-se à Cine-Channel. Equipa distribuída na UE/LatAm. Igualdade de oportunidades, em conformidade com RGPD.</p>
      <h3>Vagas 2025</h3>
      <ul>
        <li>Frontend (Next.js/React)</li>
        <li>Backend (Node/Prisma/PostgreSQL)</li>
        <li>Engenheiro de Vídeo/Streaming</li>
        <li>Community &amp; Parcerias</li>
      </ul>
      <p>Envie CV e portfólio para <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> com disponibilidade e faixa salarial.</p>
    </div>
  );
}
