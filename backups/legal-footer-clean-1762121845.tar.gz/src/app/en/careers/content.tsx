export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Careers</h2>
      <p>Join Cine-Channel. EU/LatAm distributed team. Equal opportunity employer, GDPR-compliant.</p>
      <h3>Open roles 2025</h3>
      <ul>
        <li>Frontend Engineer (Next.js/React)</li>
        <li>Backend Engineer (Node/Prisma/PostgreSQL)</li>
        <li>Video/Streaming Engineer</li>
        <li>Community &amp; Partnerships Manager</li>
      </ul>
      <p>Send your resume &amp; portfolio to <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> with availability and salary range.</p>
    </div>
  );
}
