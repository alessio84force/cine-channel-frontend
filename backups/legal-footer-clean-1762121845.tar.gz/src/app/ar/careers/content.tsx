export default function Content(){
  return (
    <div className="prose prose-invert max-w-none" dir="rtl">
      <h2>الوظائف</h2>
      <p>انضم إلى Cine-Channel. فريق موزّع داخل الاتحاد الأوروبي وأمريكا اللاتينية. تكافؤ الفرص والامتثال للائحة GDPR.</p>
      <h3>شواغر 2025</h3>
      <ul>
        <li>واجهات أمامية (Next.js/React)</li>
        <li>خلفية (Node/Prisma/PostgreSQL)</li>
        <li>مهندس فيديو/بث</li>
        <li>إدارة المجتمع والشراكات</li>
      </ul>
      <p>أرسل السيرة الذاتية وملف الأعمال إلى <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> مع موعد التفرغ والنطاق المالي.</p>
    </div>
  );
}
