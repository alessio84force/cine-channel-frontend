export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Вакансии</h2>
      <p>Присоединяйтесь к Cine-Channel. Распределённая команда (ЕС/Латинская Америка). Равные возможности, соответствие GDPR.</p>
      <h3>Открытые позиции 2025</h3>
      <ul>
        <li>Фронтенд (Next.js/React)</li>
        <li>Бэкенд (Node/Prisma/PostgreSQL)</li>
        <li>Инженер видео/стриминга</li>
        <li>Community &amp; партнёрства</li>
      </ul>
      <p>Присылайте резюме и портфолио на <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a>, укажите доступность и вилку дохода.</p>
    </div>
  );
}
