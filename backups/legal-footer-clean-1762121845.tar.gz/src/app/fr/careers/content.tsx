export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Carrières</h2>
      <p>Rejoignez Cine-Channel. Équipe distribuée UE/LatAm. Égalité des chances, conformité RGPD.</p>
      <h3>Postes ouverts 2025</h3>
      <ul>
        <li>Ingénieur Frontend (Next.js/React)</li>
        <li>Ingénieur Backend (Node/Prisma/PostgreSQL)</li>
        <li>Ingénieur Vidéo/Streaming</li>
        <li>Community &amp; Partenariats</li>
      </ul>
      <p>Envoyez CV et portfolio à <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> avec disponibilités et prétentions.</p>
    </div>
  );
}
