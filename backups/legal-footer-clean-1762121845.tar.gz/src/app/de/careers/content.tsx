export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Karriere</h2>
      <p>Werde Teil von Cine-Channel. Verteiltes Team in EU/LatAm. Chancengleichheit, DSGVO-konform.</p>
      <h3>Offene Stellen 2025</h3>
      <ul>
        <li>Frontend (Next.js/React)</li>
        <li>Backend (Node/Prisma/PostgreSQL)</li>
        <li>Video/Streaming Engineer</li>
        <li>Community &amp; Partnerschaften</li>
      </ul>
      <p>Bewerbungen an <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> mit Verfügbarkeit und Gehaltsvorstellung.</p>
    </div>
  );
}
