export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>招聘</h2>
      <p>加入 Cine-Channel。欧盟/拉美分布式团队。机会均等，符合 GDPR 要求。</p>
      <h3>2025 招聘岗位</h3>
      <ul>
        <li>前端工程师（Next.js/React）</li>
        <li>后端工程师（Node/Prisma/PostgreSQL）</li>
        <li>视频/流媒体工程师</li>
        <li>社区与合作伙伴经理</li>
      </ul>
      <p>请将简历与作品集发送至 <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a>，附上可入职时间与薪资期望。</p>
    </div>
  );
}
