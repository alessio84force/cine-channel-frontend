export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Trabaja con nosotros</h2>
      <p>Únete a Cine-Channel. Equipo distribuido en UE y LatAm. Igualdad de oportunidades y cumplimiento RGPD.</p>
      <h3>Puestos abiertos 2025</h3>
      <ul>
        <li>Frontend (Next.js/React)</li>
        <li>Backend (Node/Prisma/PostgreSQL)</li>
        <li>Ingeniería de Vídeo/Streaming</li>
        <li>Community &amp; Partnerships</li>
      </ul>
      <p>Envía CV y portfolio a <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a> indicando disponibilidad y rango salarial.</p>
    </div>
  );
}
