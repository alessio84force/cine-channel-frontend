export default function Content(){
  return (
    <div className="prose prose-invert max-w-none">
      <h2>Lavora con noi</h2>
      <p>Unisciti a Cine-Channel. Team distribuito UE/LatAm. Pari opportunità e conformità GDPR.</p>
      <h3>Posizioni aperte 2025</h3>
      <ul>
        <li>Frontend (Next.js/React)</li>
        <li>Backend (Node/Prisma/PostgreSQL)</li>
        <li>Ingegnere Video/Streaming</li>
        <li>Community &amp; Partnerships</li>
      </ul>
      <p>Invia CV e portfolio a <a href="mailto:jobs@cine-channel.com">jobs@cine-channel.com</a>, con disponibilità e RAL.</p>
    </div>
  );
}
