import { NextResponse } from "next/server";

export async function GET() {
  // 1) Tenta NextAuth, se esiste
  try {
    const r = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ""}/api/auth/session`, {
      headers: { "cookie": "" }, // in Edge runtime non abbiamo cookie lato server
      cache: "no-store",
    }).then(async (res) => {
      if (!res.ok) throw new Error("no nextauth");
      return res.json();
    }).catch(() => null);

    if (r && r.user && (r.user.email || r.user.name)) {
      return NextResponse.json({ ok: true, user: r.user }, { status: 200 });
    }
  } catch (_) {}

  // 2) Fallback: leggi cookie semplici impostati dal tuo login custom
  //    (adatta questi nomi ai tuoi cookie reali)
  const reqCookies = (await import("next/headers")).cookies();
  const email = reqCookies.get("cc_user_email")?.value || "";
  const name  = reqCookies.get("cc_user_name")?.value  || "";
  if (email || name) {
    return NextResponse.json({ ok: true, user: { email, name } }, { status: 200 });
  }

  return NextResponse.json({ ok: false }, { status: 200 });
}
