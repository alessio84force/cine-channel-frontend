import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/db";
import { credSchema } from "@/lib/auth/schemas";
import bcrypt from "bcryptjs";
import { JWT } from "@/lib/auth/jwt";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, password } = credSchema.parse(body);
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

    const token = await JWT.sign({ sub: user.id, email: user.email });
    const res = NextResponse.json({ ok: true });
    res.cookies.set(JWT.name, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7
    });
    return res;
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Bad Request" }, { status: 400 });
  }
}
