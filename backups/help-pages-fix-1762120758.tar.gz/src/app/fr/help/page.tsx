import LegalLayout from "@/components/legal/LegalLayout";
import LegalHTML from "@/components/legal/LegalHTML";
import { HELP_2025 } from "@/legal/texts/misc";

export default function Page(){
  const html = HELP_2025["fr"] || HELP_2025["en"];
  return (
    <LegalLayout title={"Aide
Hilfe
Ajuda
المساعدة
Помощь
帮助
도움말" >
      <LegalHTML html={html} />
    </LegalLayout>
  );
}
