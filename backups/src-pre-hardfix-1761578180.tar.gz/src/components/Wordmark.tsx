import React from "react";

type Props = {
  className?: string;
  withStars?: boolean; // default: true
  title?: string;
};

export default function Wordmark({ className = "", withStars = true, title = "CINE-CHANNEL" }: Props) {
  const VIEW_W = 1600; const VIEW_H = 240;
  const TEXT_X = 300;  const TEXT_LEN = 1000; // scritta forzata su una riga
  const STAR_SIZE = 112; const STAR_GAP = 26;
  const LEFT_STAR_X  = TEXT_X - STAR_GAP - STAR_SIZE;
  const RIGHT_STAR_X = TEXT_X + TEXT_LEN + STAR_GAP;

  return (
    <svg
      className={className}
      viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
      role="img"
      aria-label={title}
      xmlns="http://www.w3.org/2000/svg"
      preserveAspectRatio="xMidYMid meet"
      style={{ overflow: "visible" }}
    >
      <defs>
        <linearGradient id="gold-3d" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#fff6db"/>
          <stop offset="14%"  stopColor="#f6da7b"/>
          <stop offset="32%"  stopColor="#d4af37"/>
          <stop offset="55%"  stopColor="#8c6a10"/>
          <stop offset="72%"  stopColor="#d4af37"/>
          <stop offset="88%"  stopColor="#f3cf6b"/>
          <stop offset="100%" stopColor="#a97c15"/>
        </linearGradient>
        <linearGradient id="specular" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"   stopColor="#ffffff" stopOpacity="0"/>
          <stop offset="50%"  stopColor="#ffffff" stopOpacity="0.55"/>
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0"/>
        </linearGradient>
        <mask id="softHighlight">
          <rect x="0" y="0" width={VIEW_W} height={VIEW_H} fill="black"/>
          <ellipse cx={TEXT_X + TEXT_LEN/2} cy="120" rx="520" ry="48" fill="white"/>
        </mask>
        <symbol id="cineStar" viewBox="0 0 100 100">
          <path d="M50 2 L61 38 L98 38 L68 59 L79 95 L50 74 L21 95 L32 59 L2 38 L39 38 Z"/>
        </symbol>
        <filter id="bevel" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="1.2" result="blur"/>
          <feSpecularLighting in="blur" surfaceScale="4" specularConstant="0.9" specularExponent="24" lightingColor="#fff">
            <fePointLight x="-80" y="-60" z="120"/>
          </feSpecularLighting>
          <feComposite in2="SourceAlpha" operator="in"/>
          <feComposite in2="SourceGraphic" operator="arithmetic" k1="0" k2="1" k3="1" k4="0"/>
        </filter>
      </defs>

      {/* Stella sinistra */}
      {withStars && (
        <g transform={`translate(${LEFT_STAR_X},25) scale(${STAR_SIZE/100})`}>
          <use href="#cineStar" fill="url(#gold-3d)" filter="url(#bevel)"/>
          <use href="#cineStar" fill="none" stroke="#3f2a06" strokeWidth="3"/>
          <use href="#cineStar" fill="url(#specular)" mask="url(#softHighlight)"/>
        </g>
      )}

      {/* Scritta unica (una riga) */}
      <g transform="translate(0,0)">
        <text
          x={TEXT_X} y={150}
          fontFamily="Cinzel, 'Trajan Pro', serif"
          fontWeight="800"
          fontSize="132"
          letterSpacing="6"
          lengthAdjust="spacingAndGlyphs"
          textLength={TEXT_LEN}
          fill="url(#gold-3d)"
          stroke="#3f2a06"
          strokeWidth="2.5"
          paintOrder="stroke"
        >
          CINE-CHANNEL
        </text>
        {/* highlight morbido */}
        <text
          x={TEXT_X} y={150}
          fontFamily="Cinzel, 'Trajan Pro', serif"
          fontWeight="800"
          fontSize="132"
          letterSpacing="6"
          lengthAdjust="spacingAndGlyphs"
          textLength={TEXT_LEN}
          fill="url(#specular)"
          mask="url(#softHighlight)"
        >
          CINE-CHANNEL
        </text>
      </g>

      {/* Stella destra */}
      {withStars && (
        <g transform={`translate(${RIGHT_STAR_X},25) scale(${STAR_SIZE/100})`}>
          <use href="#cineStar" fill="url(#gold-3d)" filter="url(#bevel)"/>
          <use href="#cineStar" fill="none" stroke="#3f2a06" strokeWidth="3"/>
          <use href="#cineStar" fill="url(#specular)" mask="url(#softHighlight)"/>
        </g>
      )}
    </svg>
  );
}
