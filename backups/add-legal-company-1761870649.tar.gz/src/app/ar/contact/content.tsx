export default function Content(){ return (<div><p>General contact: contact@cine-channel.example</p>
<p>Support: support@cine-channel.example · Legal: legal@cine-channel.example</p></div>); }
