export default function Content(){ return (<div><h2>1. What We Use</h2>
<ul>
  <li>Strictly necessary (auth, load balancing, consent storage).</li>
  <li>Preferences (language, volume).</li>
  <li>Analytics (aggregated usage) – consent where required.</li>
  <li>Advertising/affiliates – disabled by default; enabled only with consent in applicable regions.</li>
</ul>
<h2>2. Choices</h2>
<p>Consent banner at first visit; Manage from Settings __BODY__gt; Privacy __BODY__gt; Cookies at any time. Browser settings may also block cookies.</p>
<h2>3. Retention</h2>
<p>Most cookies expire between session and 13 months depending on purpose and legal limits.</p></div>); }
