export default function Content(){ return (<div><h2>1. DMCA Notice</h2>
<p>If you believe your copyright is infringed, send a notice including: (a) your signature; (b) work identified; (c) material location (URL); (d) contact info; (e) good-faith statement; (f) statement under penalty of perjury of accuracy and ownership/authorization.</p>
<p>Send to our agent: dmca@cine-channel.example</p>
<h2>2. Counter-Notice</h2>
<p>If you believe removal was a mistake, send a counter-notice including: (a) your signature; (b) identification of removed material and its location before removal; (c) statement under penalty of perjury; (d) your contact info and consent to jurisdiction.</p>
<h2>3. Non-US</h2>
<p>We accept equivalent notices under local laws (e.g., EU E-Commerce/DSA notice). Use the same channel.</p></div>); }
