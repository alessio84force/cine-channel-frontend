export default function Content(){ return (<div><p><strong>Last updated:</strong> 2025-10-31</p>
<h2>1. Controller __BODY__amp; Contacts</h2>
<p>CINE-CHANNEL is the data controller. Contact: privacy@cine-channel.example. EU/UK representatives (if applicable) are listed in our Imprint.</p>
<h2>2. Data We Process</h2>
<ul>
  <li>Account data (name, email, locale), authentication logs.</li>
  <li>Content __BODY__amp; comments, messages, channel settings.</li>
  <li>Technical data: IP, device, app version, diagnostics, crash logs.</li>
  <li>Cookies/identifiers for security, preferences, analytics (with consent where required).</li>
  <li>Payments data via processors; we do not store full card numbers.</li>
</ul>
<h2>3. Purposes __BODY__amp; Legal Bases</h2>
<ul>
  <li>Provide the Service (contract); secure and debug (legitimate interests).</li>
  <li>Consent-based analytics/marketing where required.</li>
  <li>Compliance with law and requests (legal obligation).</li>
</ul>
<h2>4. Sharing</h2>
<p>Service providers (hosting, analytics, payments, anti-abuse); with other users per your settings; with authorities where legally required. International transfers use SCCs or equivalent safeguards.</p>
<h2>5. Retention</h2>
<p>As long as needed for the purpose, then securely deleted or anonymized. Key logs rotate within 12–24 months unless needed for security/legal.</p>
<h2>6. Your Rights</h2>
<p>Access, rectification, deletion, portability, restriction, objection; withdraw consent anytime. EU/UK: lodge a complaint with your DPA/ICO. Québec: contact CAI. California/US states: rights per applicable state law (access, delete, opt-out of sales/sharing, limit sensitive data).</p>
<h2>7. Children</h2>
<p>No targeted ads to minors where prohibited. Parental consent required where applicable.</p>
<h2>8. DPO</h2>
<p>Contact: privacy@cine-channel.example</p>
<h2>9. Cookies</h2>
<p>See our Cookies Policy for details and choices.</p></div>); }
