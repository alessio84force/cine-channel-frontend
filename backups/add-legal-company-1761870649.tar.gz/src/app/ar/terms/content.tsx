export default function Content(){ return (<div><h2>1. Overview</h2>
<p>These Terms govern your use of the CINE-CHANNEL platform. By using the Service you agree to these Terms.</p>
<h2>2. Accounts __BODY__amp; Age</h2>
<p>You must be at least 13 (or the minimum age required in your country) and capable of forming a binding contract. Provide accurate information and keep your credentials secure.</p>
<h2>3. User Content __BODY__amp; Licenses</h2>
<p>You retain ownership of your content. You grant us a worldwide, non-exclusive, royalty-free license to host, store, display, transmit and create non-derivative technical copies solely to operate and improve the Service. You also grant other users a license to view your public content through the Service.</p>
<h2>4. Prohibited Conduct</h2>
<ul>
  <li>Illegal content; CSAM; incitement to violence or hate; doxxing; phishing; malware; spam.</li>
  <li>IP infringement, including unauthorized streaming or distribution.</li>
  <li>Attempting to bypass access controls, scraping at scale, or service disruption.</li>
</ul>
<h2>5. Moderation __BODY__amp; Notice</h2>
<p>We may remove or restrict content that violates these Terms or the law. You may appeal moderation decisions. EU users may use our DSA complaint channel.</p>
<h2>6. Copyright Repeat-Infringer Policy</h2>
<p>Accounts subject to repeat, valid copyright notices may be terminated.</p>
<h2>7. Payments</h2>
<p>Creators may monetize in supported regions; fees, taxes and payout terms are disclosed at onboarding. Refunds follow applicable consumer laws.</p>
<h2>8. Disclaimers __BODY__amp; Liability</h2>
<p>Service is provided “as is”. To the extent permitted by law, we exclude implied warranties and limit liability for indirect or consequential damages.</p>
<h2>9. Governing Law __BODY__amp; Disputes</h2>
<p>For EU/UK consumers: local mandatory consumer law applies. For others: laws of Spain, courts of Madrid, unless mandatory law states otherwise. Arbitration may apply to business users.</p>
<h2>10. Changes</h2>
<p>We may update these Terms; material changes will be notified at least 15 days in advance where required.</p></div>); }
