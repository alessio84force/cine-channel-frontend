"use client";
import Link from "next/link";
import { COMPANY } from "@/legal/company";

export default function LegalLayout({title, children}:{title:string, children:React.ReactNode}) {
  return (
    <main className="max-w-3xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold mb-2">{title}</h1>
      <p className="text-white/60 mb-8">{COMPANY.trademark} · {COMPANY.name}</p>
      <article className="prose prose-invert prose-sm sm:prose-base max-w-none">
        {children}
      </article>
      <hr className="my-10 border-white/10" />
      <nav className="text-sm flex flex-wrap gap-3 text-white/70">
        <Link href="/en/terms" className="hover:underline">Terms</Link>
        <Link href="/en/privacy" className="hover:underline">Privacy</Link>
        <Link href="/en/cookies" className="hover:underline">Cookies</Link>
        <Link href="/en/copyright" className="hover:underline">Copyright</Link>
        <Link href="/en/dmca" className="hover:underline">DMCA</Link>
        <Link href="/en/imprint" className="hover:underline">Imprint</Link>
        <Link href="/en/accessibility" className="hover:underline">Accessibility</Link>
        <Link href="/en/help" className="hover:underline">Help</Link>
        <Link href="/en/press" className="hover:underline">Press</Link>
        <Link href="/en/careers" className="hover:underline">Careers</Link>
        <Link href="/en/contact" className="hover:underline">Contact</Link>
      </nav>
    </main>
  );
}
