"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import Wordmark from "@/components/Wordmark";
import { dict, type Locale } from "@/i18n/dict";

type SessionUser = { email?: string; name?: string };

export default function NavBar({ locale = "es" }: { locale?: Locale }) {
  const t = dict[locale] || dict.es;
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/session", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => { if (alive) setUser(d?.ok && d.user ? d.user : null); })
      .catch(() => setUser(null));
    return () => { alive = false; };
  }, []);

  const initials = (() => {
    const mail = user?.email || "";
    const before = mail.split("@")[0] || "";
    return (before.slice(0, 4) || (user?.name || "USER").slice(0, 4)).toUpperCase();
  })();

  return (
    <header className="border-b border-white/10">
      <div className="mx-auto max-w-6xl px-4 h-16 flex items-center gap-4">
        {/* Sinistra: Logo/Home */}
        <Link href={`/${locale}`} aria-label="Home" className="shrink-0">
          <Wordmark withStars className="w-[132px] md:w-[156px] h-auto align-middle" />
        </Link>

        {/* Centro: bottoni */}
        <nav className="mx-auto flex items-center gap-3">
          <Link
            href={`/${locale}/explore`}
            className="inline-flex items-center rounded-xl px-4 py-2 bg-white text-neutral-900 font-medium hover:opacity-90"
          >
            {t.navbar.explore}
          </Link>
          <Link
            href={`/${locale}/creator/onboarding`}
            className="inline-flex items-center rounded-xl px-4 py-2 bg-white text-neutral-900 font-medium hover:opacity-90"
          >
            {t.navbar.create}
          </Link>
        </nav>

        {/* Destra: lingue + login/utente */}
        <div className="ml-auto flex items-center gap-2 text-xs">
          <Link href="/es" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">ES</Link>
          <Link href="/en" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">EN</Link>
          <Link href="/fr" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">FR</Link>
          <Link href="/it" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">IT</Link>
          <Link href="/de" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">DE</Link>
          <Link href="/pt" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">PT</Link>
          <Link href="/ar" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">AR</Link>
          <Link href="/ru" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">RU</Link>
          <Link href="/zh" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">ZH</Link>
          <Link href="/ko" className="px-2 py-1 rounded hover:bg-white/10 text-white/80">KO</Link>

          <div className="w-px h-4 bg-white/15 mx-1" />

          {!user ? (
            <Link
              href={`/${locale}/signin?callbackUrl=/${locale}`}
              className="text-sm hover:underline"
            >
              {t.navbar.login}
            </Link>
          ) : (
            <Link
              href={`/${locale}/account`}
              className="inline-flex items-center rounded-full border border-white/25 bg-white/5 px-3 py-1 text-sm tracking-wide"
              title={user.email || user.name || ""}
            >
              {initials}
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
