import { NextResponse } from "next/server";
import { z } from "zod";
import { verifyUser } from "@/lib/auth";

const credSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const parsed = credSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }
  const { email, password } = parsed.data;
  const user = await verifyUser(email, password);
  if (!user) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true, user }, { status: 200 });
  res.headers.set("Cache-Control", "no-store");
  res.cookies.set("cc_user_email", user.email, { httpOnly: true, path: "/", maxAge: 60 * 60 * 24 * 30 });
  res.cookies.set("cc_user_name", user.name,  { httpOnly: true, path: "/", maxAge: 60 * 60 * 24 * 30 });
  return res;
}
