import { NextResponse } from "next/server";

export async function POST() {
  const res = NextResponse.json({ ok: true });
  // Elimina i cookie "demo"
  res.cookies.set("cc_user_email", "", { httpOnly: true, path: "/", maxAge: 0 });
  res.cookies.set("cc_user_name",  "", { httpOnly: true, path: "/", maxAge: 0 });
  res.headers.set("Cache-Control", "no-store");
  return res;
}
