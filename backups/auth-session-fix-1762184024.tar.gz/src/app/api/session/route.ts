import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET() {
  const store = await cookies();
  const email = store.get("cc_user_email")?.value || "";
  const name  = store.get("cc_user_name")?.value  || "";
  if (email || name) {
    return NextResponse.json({ ok: true, user: { email, name } }, { status: 200 });
  }
  return NextResponse.json({ ok: false }, { status: 200 });
}
