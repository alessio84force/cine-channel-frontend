import { COMPANY } from "@/legal/company";
export default function Content(){
  return (<div>
    <h2>Responsable del tratamiento</h2>
    <p>{COMPANY.name}, {COMPANY.address}, {COMPANY.zip} {COMPANY.city}, {COMPANY.country}. Email DPO: <a href={`mailto:${COMPANY.dpoEmail}`}>{COMPANY.dpoEmail}</a>.</p>
    <h2>Datos que tratamos</h2>
    <ul>
      <li>Cuenta e identidad (nombre, email, contraseña cifrada).</li>
      <li>Uso (logs, métricas, cookies).</li>
      <li>Pagos/monetización (a través de terceros).</li>
      <li>Contenido generado por el usuario.</li>
    </ul>
    <h2>Fines y bases legales</h2>
    <ul>
      <li>Ejecución del contrato (proveer la plataforma).</li>
      <li>Consentimiento (marketing, cookies no esenciales).</li>
      <li>Interés legítimo (seguridad, prevención de fraude).</li>
      <li>Obligación legal (fiscal, requerimientos).</li>
    </ul>
    <h2>Transferencias internacionales</h2>
    <p>Si procede, amparamos transferencias con garantías adecuadas (SCC/UK IDTA).</p>
    <h2>Retención</h2>
    <p>Conservamos datos mientras la cuenta esté activa y según plazos legales.</p>
    <h2>Derechos</h2>
    <p>Acceso, rectificación, supresión, oposición, limitación y portabilidad. Solicitudes a <a href={`mailto:${COMPANY.dpoEmail}`}>{COMPANY.dpoEmail}</a>.</p>
    <h2>Cookies</h2>
    <p>Ver <a href="/es/cookies">Política de Cookies</a>. Puedes gestionar preferencias.</p>
    <h2>Contacto</h2>
    <p><a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a> · Soporte: <a href={`mailto:${COMPANY.supportEmail}`}>{COMPANY.supportEmail}</a></p>
    <p className="mt-6 text-white/50 text-sm">Vigente desde: 2025-10-31</p>
  </div>);
}
