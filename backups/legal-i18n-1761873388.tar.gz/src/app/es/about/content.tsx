import { COMPANY } from "@/legal/company";
export default function Content(){
  return (<div>
    <h2>Quiénes somos</h2>
    <p>{COMPANY.name} ({COMPANY.vatNumber}). {COMPANY.address}, {COMPANY.zip} {COMPANY.city}, {COMPANY.country}. Registro: {COMPANY.regNumber}.</p>
    <h2>Contacto</h2>
    <p>Email: <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a> · Soporte: <a href={`mailto:${COMPANY.supportEmail}`}>{COMPANY.supportEmail}</a></p>
  </div>);
}
