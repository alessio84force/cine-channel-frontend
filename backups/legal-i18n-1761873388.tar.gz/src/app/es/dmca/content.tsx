import { COMPANY } from "@/legal/company";
export default function Content(){
  return (<div>
    <h2>Notificación de infracción</h2>
    <p>Envía un aviso con: obra titular, URL infractora, declaración de buena fe y autoridad, a <a href={`mailto:${COMPANY.copyrightAgentEmail}`}>{COMPANY.copyrightAgentEmail}</a>.</p>
    <h2>Contranotificación</h2>
    <p>Si crees que fue un error, puedes enviar contranotificación con tus datos y fundamento.</p>
  </div>);
}
