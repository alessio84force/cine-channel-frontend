import { COMPANY } from "@/legal/company";
export default function Content(){
  return (<div>
    <h2>Soporte</h2>
    <p>Escríbenos a <a href={`mailto:${COMPANY.supportEmail}`}>{COMPANY.supportEmail}</a>. Atendemos en días laborables.</p>
    <h2>Privacidad</h2>
    <p>Para derechos de datos personales: <a href={`mailto:${COMPANY.dpoEmail}`}>{COMPANY.dpoEmail}</a>.</p>
    <h2>Prensa / Legal</h2>
    <p><a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a></p>
  </div>);
}
