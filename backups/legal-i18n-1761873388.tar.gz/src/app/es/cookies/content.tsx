export default function Content(){
  return (<div>
    <h2>¿Qué son las cookies?</h2>
    <p>Pequeños archivos para recordar preferencias y mejorar seguridad y analítica.</p>
    <h2>Tipos</h2>
    <ul>
      <li>Esenciales (autenticación, seguridad) — siempre activas.</li>
      <li>Analíticas/Medición — consentimiento.</li>
      <li>Marketing — consentimiento.</li>
    </ul>
    <h2>Gestión</h2>
    <p>Puedes configurar tu navegador y el panel de preferencias del sitio.</p>
  </div>);
}
