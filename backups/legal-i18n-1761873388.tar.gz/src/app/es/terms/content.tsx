import { COMPANY } from "@/legal/company";
export default function Content(){
  return (<div>
    <h2>1. Aceptación</h2>
    <p>Al usar la plataforma, aceptas estos Términos (2025). Si no estás de acuerdo, no uses el servicio.</p>
    <h2>2. Cuenta y edad</h2>
    <p>Debes tener 16+ o la mayoría de edad en tu país. Eres responsable de mantener la seguridad de tu cuenta.</p>
    <h2>3. Contenido del usuario</h2>
    <p>Eres titular de tus obras. Nos concedes una licencia mundial, no exclusiva y revocable para alojar, reproducir y mostrar tu contenido en el servicio con fines operativos.</p>
    <h2>4. Prohibiciones</h2>
    <ul>
      <li>Ilegalidad, infracción de derechos, acoso, spam, malware.</li>
      <li>Publicidad engañosa, suplantación, scraping no autorizado.</li>
    </ul>
    <h2>5. Monetización y pagos</h2>
    <p>Pagos gestionados por terceros (p.ej. Stripe). Pueden aplicar comisiones e impuestos. Proporciona datos fiscales válidos.</p>
    <h2>6. Propiedad intelectual</h2>
    <p>Respeta derechos de terceros. Avisos a <a href={`mailto:${COMPANY.copyrightAgentEmail}`}>{COMPANY.copyrightAgentEmail}</a>.</p>
    <h2>7. Protección de datos</h2>
    <p>Cumplimos RGPD/UE y normativa aplicable. Consulta la <a href="/es/privacy">Privacidad</a>.</p>
    <h2>8. Responsabilidad</h2>
    <p>El servicio se ofrece “tal cual”. {COMPANY.shortName||COMPANY.name} no garantiza disponibilidad continua. Responsabilidad limitada según ley aplicable.</p>
    <h2>9. Ley y jurisdicción</h2>
    <p>{COMPANY.jurisdiction}. Consumidores conservan derechos imperativos de su país.</p>
    <h2>10. Cambios</h2>
    <p>Podemos actualizar estos Términos. Te notificaremos cambios materiales.</p>
    <p className="mt-6 text-white/50 text-sm">Última actualización: 2025-10-31</p>
  </div>);
}
