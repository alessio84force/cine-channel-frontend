import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET() {
  const jar = await cookies();
  const email = jar.get("cc_user_email")?.value || "";
  const name  = jar.get("cc_user_name")?.value  || "";
  const res = NextResponse.json({ ok: !!(email || name), user: (email||name) ? { email, name } : null }, { status: 200 });
  res.headers.set("Cache-Control","no-store");
  return res;
}
