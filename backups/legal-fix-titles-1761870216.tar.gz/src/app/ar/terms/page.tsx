import LegalLayout from "@/components/legal/LegalLayout";
import Content from "./content";
export default function Page(){ return <LegalLayout title={Terms of Service}><Content/></LegalLayout>; }
